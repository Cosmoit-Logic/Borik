# config.py

# Токен твоего Telegram-бота от @BotFather
# Убедитесь, что используете свой актуальный токен
BOT_TOKEN = "8129088858:AAFb2YN6iKEP5a2lLcTOwjVrpbi37zuGmRQ" 

# Токен от alerts.in.ua
# Убедитесь, что используете свой актуальный токен
API_TOKEN = "bf52a19c09ed2c2abb6a3c884dd4a96c2b3ab08eab2203"

# Твой личный Telegram User ID.
# ВАЖНО: Указан ваш ID, как вы и просили.
BOT_OWNER_ID = 6179115044

# URL карты тревог
ALERTS_MAP_URL = "https://alerts.in.ua/"